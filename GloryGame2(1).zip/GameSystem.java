
public class GameSystem {
	
	//Constants
	private static final int CAPACITY = 3;
	private static final int CURRENT_PLAYER = 0;
	//Instance variables
	public Player[] players;
	public int fineSquares[];
	public int cliffSquares[];
	public int status;
	public int currentPlayer;
	public int boardSize;
	public String winner;
 
	
	 
	
	//Constructor
	public GameSystem() {
		players = new Player[CAPACITY];
		currentPlayer = CURRENT_PLAYER;
		
	}
	
	//Methods
	
	//Creates and returns a Player object.
	public Player createPlayer(String name) {
		Player player = new Player(name);
		return player;
	}
	
	//Method responsible for registering the  players.
	public void registPlayers(String playersIn) {
		for(int i=0;i<CAPACITY;i++) {
			players[i] =createPlayer(Character.toString(playersIn.charAt(i)));
		}
	}
	
	//Return the next player that gets to play
	public String nextPlayer() {
		return players[currentPlayer].getName();
	}
	
	//dice
	public void throwDices(int dice1, int dice2) {
		int steps = dice1+dice2;
		movePlayer(steps);
		if(isOnCliffSquare()){
			cliffSquarePenalties(steps);
		}else if(isOnFineSquare()){
			fineSquarePenalties();
		}else if(isAtBirdSquare(players[currentPlayer].getPosition())){
			birdSquarePenalties(steps);
		}
		switchToNextValidPlayer();
	}
	//Method to check if the game is over 
	public boolean gameIsOver() {
		boolean isOver= false; 
		for(int i=0;i<CAPACITY;i++) {
			if(players[i].getPosition()==boardSize) {
				isOver = true;
			}
		}
		return isOver;
	}
	//Method resposnsible for returning the players square
	public int currentSquare(String player) {
		int square = 0;
		for (int i=0;i<CAPACITY;i++) {
			if(players[i].getName().equals(player)) {
				square = players[i].getPosition();
			}
		}
		return square;
	}
	public String getPlayerName(int n) {
		return players[n].getName();
	}
	//Method responsible for checking if a player exists
	public boolean exists(String player) {
		boolean exists = false;
		for (int i=0;i<CAPACITY;i++) {
			if(players[i].getName().equals(player)) {
				exists = true;
			}
		}
		return exists;
	}
	//Method that sets the boards size
	public void setBoardSize(int size) {
		boardSize = size;
	}
	//Method that checks if a player can roll the dice 
	public boolean canRollDice(String playerColor) {
		boolean canRoll = false;
		int playerFine = 0;
		for (int i=0;i<CAPACITY;i++){
			if(players[i].getName().equals(playerColor)) {
				playerFine = players[i].getFine();
			}
		}
		return playerFine ==0;
		
	}
	//Method responsible for checking the validation of the thots of a dice
	public boolean areValidThots (int thots) {
			return thots<=6 && thots>=1;
	}
	
	//Method that return the winner of the game 
	public String gameWinner() {
		String colorWinner = "";
		for (int i=0;i<CAPACITY;i++){
			if(players[i].getPosition()==boardSize) {
				colorWinner  = players[i].getName();
			}
		}
		return colorWinner;
	}

	//Method responsible for moving the current valid player
	public void movePlayer(int steps) {
		players[currentPlayer].setPosition(steps);
		reajustBoundaries();
	}
	//Method responsible for applying the cliff square penalties
	public void cliffSquarePenalties(int steps) {
		players[currentPlayer].setPosition((-steps)*2);
		reajustBoundaries();
	}
	//Method responsible for applying the fine square penalties
	public void fineSquarePenalties() {
		players[currentPlayer].setFine(2);;
	}
	//Method responsible for applying the bird square penalties
	public void birdSquarePenalties(int steps) {
		players[currentPlayer].setPosition(9);
		reajustBoundaries();
	}
	//Method resposnible for reajusting positions out of boundaries
	public void reajustBoundaries() {
		if(players[currentPlayer].getPosition()>boardSize) {
			players[currentPlayer].setAtFinalPosition(boardSize);
		}
		if(players[currentPlayer].getPosition()<1){
			players[currentPlayer].setAtIinitialPosition(1);
		}
	}
	
	//Method responsible for checking who is the next valid player
	public void switchToNextValidPlayer() {
		switchToNextPlayer();
		while(players[currentPlayer].getFine()>0) {
			players[currentPlayer].setFine(-1);
			switchToNextPlayer();
		}
	}

	//Method that checks if a number is multiple of nine 
	public boolean isAtBirdSquare(int number) {
		return number%9==0;
	}
	//Method responsible for switcing the players turn to play
	public void switchToNextPlayer() {		
		if(currentPlayer==2) {
			currentPlayer = 0;
		}else {
			currentPlayer ++;
		}
	}
	
	public boolean isOnFineSquare() {
		boolean fineSquare = false;
		for(int i = 0;i<fineSquares.length;i++) {
			if(players[currentPlayer].getPosition()==fineSquares[i]) {
				fineSquare = true;
			}
		}
		return fineSquare;
	}
	
	public boolean isOnCliffSquare() {
		boolean cliffSquare =false;
		for(int i = 0;i<cliffSquares.length;i++) {
			if(players[currentPlayer].getPosition()==cliffSquares[i]) {
				cliffSquare = true;
			}
		}
		return cliffSquare;
	}
}
