
public class Player {
	
	//Constants
	private static final int INITIAL_POSITION = 1;
	//Instance variables
	String name;
	int position;
	int fine;
	
	//Player Constructor
	public Player(String name) {
		this.name = name;
		this.position = INITIAL_POSITION;
	}
	
	//Methods 
	
	//Returns the name of the object
	public String getName() {
		return name;
	}
	
	//Returns the players position
	public int getPosition() {
		return position;
	}
	
	//Sets the players position
	public void setPosition(int steps) {
		position += steps;
	}
	
	//Sets the player on the final position
	public void setAtFinalPosition(int finalPosition) {
		position = finalPosition;
	}
	//Sets the player on the initial position
	public void setAtIinitialPosition(int initialPosition) {
		position = initialPosition;
	}

	//Sets the name of the object
	public void setName(String name) {
		this.name = name;
	}
	//Sets a players fine
	public void setFine(int fine) {
		this.fine += fine;
		if(this.fine<0) {
			this.fine = 0;
		}
	}
	//Return a player fine 
	public int getFine() {
		return fine;
	}
}
