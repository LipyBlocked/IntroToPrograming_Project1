import java.util.Scanner;


public class Main {
	
	//Constants referring to the possible option
	public static final String PLAYER = "player";
	public static final String SQUARE = "square";
	public static final String STATUS = "status";
	public static final String DICE = "dice";
	public static final String EXIT = "exit";
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		GameSystem gloryGame = iniciateGame();
		executeOption(in,gloryGame);
		
	}
	
	//Method responsible to create a GameSystem object.
	private static GameSystem iniciateGame() {
		GameSystem game = new GameSystem();
		return game;
	}
	
	//Method responsible for the commands interpretation.
	public static void executeOption(Scanner in, GameSystem game) {
		gameSettings(game,in);
		String option;
		do {
			option = in.next();
			switch(option) {
			case PLAYER :processNextPlayer(game);break;
			case SQUARE :processSquare(game,in);break;
			case STATUS :processStatus(game,in);break;
			case DICE   :processDice(game,in);break;
			case EXIT   :exitCommand(game);break;
			default : invalidCommand(in);break;
		}
		}while(!option.equals(EXIT));
		in.close();
		
	}
	//Method resposnsible for setting the game settings
	public static void gameSettings(GameSystem game,Scanner in) {
		String players = in.next();
		game.registPlayers(players);
		game.setBoardSize(in.nextInt());
		addFines(game,in);
		addCliffs(game,in);
	}
	//Method responsible for processing who is the next player.
	public static void processNextPlayer(GameSystem game) {
		if(game.gameIsOver()) {
			System.out.println("The game is over");
		}else {
			System.out.println("Next to play: "+game.nextPlayer());
		}
	}
	//Method responsible for processing in witch square a player is 
	public static void processSquare(GameSystem game,Scanner in) {
		String playerColor = in.nextLine().trim();
		if(!game.exists(playerColor)) {
			System.out.println("Nonexistent player");
		}else {
			System.out.println(playerColor+" is on square "+game.currentSquare(playerColor));
		}
	}
	//Method that checks if the player can roll the dice or not.
	public static void processStatus(GameSystem game, Scanner in) {
		String playerColor = in.nextLine().trim();
		if(!game.exists(playerColor)) {
			System.out.println("Nonexistent player");
		}else if(game.gameIsOver()) {
			System.out.println("The game is over");
		}else if (game.canRollDice(playerColor)) {
			System.out.println(playerColor+" can roll the dice");
		}else {
			System.out.println(playerColor+" cannot roll the dice");
		}
	}
	public static void processDice(GameSystem game, Scanner in) {
		int dice1Thots = in.nextInt();
		int dice2Thots = in.nextInt();
		if(!game.areValidThots(dice1Thots)||!game.areValidThots(dice2Thots)) {
			System.out.println("Invalid dice");
		}else if(game.gameIsOver()){
			System.out.println("The game is over");
		}else {
			game.throwDices(dice1Thots, dice2Thots);
		}
	}
	public static void exitCommand(GameSystem game) {
		if(!game.gameIsOver()) {
			System.out.println("The game was not over yet...");
		}else {
			System.out.println(game.gameWinner()+" won the game!");
		}
	}
	public static void invalidCommand(Scanner in) {
		System.out.println("Invalid command");
		in.nextLine();
	}
	public static void addFines(GameSystem game, Scanner in) {
		int nrOfFines = in.nextInt();
		game.fineSquares = new int [nrOfFines];
		for(int i=0;i<nrOfFines;i++) {
			int fine = in.nextInt();
			game.fineSquares[i] = fine;
		}
	}
	public static void addCliffs(GameSystem game, Scanner in) {
		int nrOfCliffs = in.nextInt();
		game.cliffSquares = new int [nrOfCliffs];
		for(int i=0;i<nrOfCliffs;i++) {
			int cliff = in.nextInt();
			game.cliffSquares[i] = cliff;
		}
	}

	
	
	

}
